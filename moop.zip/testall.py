import os
import time
from subprocess import check_output, CalledProcessError

tests_directory = "tests"
error_message = "Fatal error: exception Stdlib.Parsing.Parse_error"


print("\
 _   .-')                      _  .-')                                                  _ (`-.  \n\
( '.( OO )_                   ( \( -O )                                                ( (OO  ) \n\
 ,--.   ,--.) ,-.-')   .-----. ,------.  .-'),-----.        .-'),-----.  .-'),-----.  _.`     \ \n\
 |   `.'   |  |  |OO) '  .--./ |   /`. '( OO'  .-.  '      ( OO'  .-.  '( OO'  .-.  '(__...--'' \n\
 |         |  |  |  \ |  |('-. |  /  | |/   |  | |  |      /   |  | |  |/   |  | |  | |  /  | | \n\
 |  |'.'|  |  |  |(_//_) |OO  )|  |_.' |\_) |  |\|  |      \_) |  |\|  |\_) |  |\|  | |  |_.' | \n\
 |  |   |  | ,|  |_.'||  |`-'| |  .  '.'  \ |  | |  |        \ |  | |  |  \ |  | |  | |  .___.' \n\
 |  |   |  |(_|  |  (_'  '--'\ |  |\  \    `'  '-'  '         `'  '-'  '   `'  '-'  ' |  |      \n\
 `--'   `--'  `--'     `-----' `--' '--'     `-----'            `-----'      `-----'  `--'      \n\
")

time.sleep(0.5)
print("Initializing Compiler")
time.sleep(1)
print("Loading")
time.sleep(2)
print("")
print("======================== Compiling ========================")
print("")

try:
    print("make clean")
    print("make toplevel.native")
except:
    print("Error occured while compiling compiler.")

print("")
print("======================== Running Positive Tests ======================== \n")
print("")

for filename in os.listdir(tests_directory):
    f = os.path.join(tests_directory, filename)

    if "pos" in filename and os.path.isfile(f):
        print("File Name: " + filename)
        output = check_output(["./toplevel.native", "-a", f]).decode("utf-8")
        result = "Passed" if output != error_message else "Failed"
        print("Output: \n" + output)
        print("Result: " + result)
        print("")

print("")
print("======================== Running Negative Tests ======================== \n")
print("")

for filename in os.listdir(tests_directory):
    f = os.path.join(tests_directory, filename)

    if "neg" in filename and os.path.isfile(f):
        print("File Name: " + filename)
        os.system("./toplevel.native -a " + f + " 2> tests/outputedError.txt")
        output = check_output(["diff", "tests/errormessage.txt", "tests/outputedError.txt"]).decode("utf-8")
        result = "Passed" if output == "" else "Failed"
        print("Result: " + result)
        os.system("cat tests/outputedError.txt")
        print("")
